<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' );
/**
* The configuration file for the default theme
*
* @package VirtueMart
* @subpackage themes
* @copyright Copyright (C) 2008 soeren - All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
?>
productListStyle=browse/includes/browse_notables.tpl.php
showFeedIcon=1
showAddtocartButtonOnProductList=1
showVendorLink=0
showManufacturerLink=0
showAvailability=1
showPathway=0
useLightBoxImages=1
useGreyBoxOnCheckout=0
useAjaxCartActions=1
showFeatured=1
showlatest=1
showRecent=5