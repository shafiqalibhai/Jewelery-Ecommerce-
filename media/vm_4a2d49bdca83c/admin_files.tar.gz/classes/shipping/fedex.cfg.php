<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('FEDEX_ACCOUNT_NUMBER', '');
define ('FEDEX_METER_NUMBER', '');
define ('FEDEX_URI', '');
define ('FEDEX_TAX_CLASS', '0');
define ('FEDEX_HANDLINGFEE', '0');
define ('FEDEX_SERVICES', '');
define ('FEDEX_SIGNATURE_OPTION', '1');
define ('FEDEX_SORT_ORDER', 'DESC');
?>