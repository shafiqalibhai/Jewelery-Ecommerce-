<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('USPS_USERNAME', '');
define ('USPS_PASSWORD', '');
define ('USPS_SERVER', 'Production.ShippingAPIs.com');
define ('USPS_PATH', '/ShippingAPI.dll');
define ('USPS_PACKAGESIZE', 'REGULAR');
define ('USPS_TAX_CLASS', '0');
define ('USPS_HANDLINGFEE', '');
define ('USPS_PADDING', '15%');
define ('USPS_INTLLBRATE', '0');
define ('USPS_INTLHANDLINGFEE', '0');
define ('USPS_MACHINABLE', '0');
define ('USPS_SHOW_DELIVERY_QUOTE', '1');
define ('USPS_SHIP0', '0');
define ('USPS_SHIP1', '1');
define ('USPS_SHIP2', '0');
define ('USPS_SHIP3', '1');
define ('USPS_SHIP4', '0');
define ('USPS_SHIP5', '0');
define ('USPS_SHIP6', '1');
define ('USPS_SHIP7', '1');
define ('USPS_SHIP8', '0');
define ('USPS_SHIP9', '0');
define ('USPS_SHIP10', '0');
define ('USPS_INTL0', '1');
define ('USPS_INTL1', '0');
define ('USPS_INTL2', '0');
define ('USPS_INTL3', '1');
define ('USPS_INTL4', '0');
define ('USPS_INTL5', '1');
define ('USPS_INTL6', '0');
define ('USPS_INTL7', '0');
define ('USPS_INTL8', '0');
//define ('USPS_INTL9', '0');
?>