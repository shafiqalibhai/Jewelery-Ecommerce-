<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('BASE_SHIP1', '20.00');
define ('BASE_SHIP2', '50.00');
define ('BASE_SHIP3', '70.00');
define ('BASE_SHIP4', '10000.00');
define ('BASE_SHIP5', '');
define ('BASE_SHIP6', '');
define ('BASE_SHIP7', '');
define ('BASE_SHIP8', '');
define ('BASE_SHIP9', '');
define ('BASE_SHIP10', '');
define ('BASE_CHARGE1', '2.95');
define ('BASE_CHARGE2', '4.70');
define ('BASE_CHARGE3', '5.50');
define ('BASE_CHARGE4', '0');
define ('BASE_CHARGE5', '');
define ('BASE_CHARGE6', '');
define ('BASE_CHARGE7', '');
define ('BASE_CHARGE8', '');
define ('BASE_CHARGE9', '');
define ('BASE_CHARGE10', '');
define ('SHIPVALUE_TAX_CLASS', '3');
?>